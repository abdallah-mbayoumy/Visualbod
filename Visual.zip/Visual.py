
from flask import Flask, render_template, jsonify, request
from flask_cors import CORS
import pyodbc

app = Flask(__name__)
CORS(app)

DB_CONFIG = {
    'server': 'MORIAHH\\SQLEXPRESS',
    'database': 'Club',
    'driver': '{ODBC Driver 17 for SQL Server}',
    'trusted_connection': 'yes'
}

def get_db_connection():
    try:
        conn_str = (
            f"DRIVER={DB_CONFIG['driver']};"
            f"SERVER={DB_CONFIG['server']};"
            f"DATABASE={DB_CONFIG['database']};"
            f"Trusted_Connection={DB_CONFIG['trusted_connection']};"
        )
        conn = pyodbc.connect(conn_str)
        return conn
    except pyodbc.Error as err:
        print(f"Database connection error: {err}")
        return None

def execute_query(query, params=None):
    conn = get_db_connection()
    if not conn:
        return None
    
    try:
        cursor = conn.cursor()
        cursor.execute(query, params or ())
        columns = [column[0] for column in cursor.description]
        results = []
        for row in cursor.fetchall():
            results.append(dict(zip(columns, row)))
        cursor.close()
        conn.close()
        return results
    except pyodbc.Error as err:
        print(f"Query execution error: {err}")
        if conn:
            conn.close()
        return None

@app.route('/')
def dashboard():
    return render_template('dashboard.html')

# ============================================
# ENHANCED KPI ENDPOINTS WITH MORE METRICS
# ============================================
@app.route('/api/kpis')
def get_kpis():
    club_filter = request.args.get('club', None)
    position_filter = request.args.get('position', None)
    min_goals = request.args.get('min_goals', None)
    
    where_conditions = []
    params = []
    
    if club_filter:
        where_conditions.append("c.ClubName = ?")
        params.append(club_filter)
    
    if position_filter and position_filter != 'All':
        where_conditions.append("p.Position = ?")
        params.append(position_filter)
    
    if min_goals:
        where_conditions.append("p.GoalsScored >= ?")
        params.append(int(min_goals))
    
    where_clause = " AND " + " AND ".join(where_conditions) if where_conditions else ""
    
    # Build queries based on whether we have filters
    if where_conditions:
        queries = {
            'total_clubs': f"SELECT COUNT(DISTINCT c.ClubID) as count FROM Clubs c JOIN Players p ON c.ClubID = p.ClubID WHERE 1=1{where_clause}",
            'total_goals': f"SELECT ISNULL(SUM(p.GoalsScored), 0) as total FROM Players p JOIN Clubs c ON p.ClubID = c.ClubID WHERE 1=1{where_clause}",
            'avg_player_value': f"SELECT ISNULL(AVG(p.MarketValue), 0) as avg_value FROM Players p JOIN Clubs c ON p.ClubID = c.ClubID WHERE p.MarketValue IS NOT NULL{where_clause}",
            'total_assists': f"SELECT ISNULL(SUM(p.Assists), 0) as total FROM Players p JOIN Clubs c ON p.ClubID = c.ClubID WHERE 1=1{where_clause}",
            'total_players': f"SELECT COUNT(p.PlayerID) as count FROM Players p JOIN Clubs c ON p.ClubID = c.ClubID WHERE 1=1{where_clause}",
            'avg_age': f"SELECT AVG(CAST(p.Age AS FLOAT)) as avg_age FROM Players p JOIN Clubs c ON p.ClubID = c.ClubID WHERE 1=1{where_clause}"
        }
    else:
        queries = {
            'total_clubs': "SELECT COUNT(*) as count FROM Clubs",
            'total_goals': "SELECT ISNULL(SUM(GoalsScored), 0) as total FROM Players",
            'avg_player_value': "SELECT ISNULL(AVG(MarketValue), 0) as avg_value FROM Players WHERE MarketValue IS NOT NULL",
            'total_assists': "SELECT ISNULL(SUM(Assists), 0) as total FROM Players",
            'total_players': "SELECT COUNT(*) as count FROM Players",
            'avg_age': "SELECT AVG(CAST(Age AS FLOAT)) as avg_age FROM Players"
        }
    
    kpis = {}
    for key, query in queries.items():
        result = execute_query(query, params if where_conditions else None)
        if result and len(result) > 0:
            value = list(result[0].values())[0]
            kpis[key] = value if value is not None else 0
        else:
            kpis[key] = 0
    
    # Debug logging
    print(f"KPIs calculated: {kpis}")
    
    return jsonify(kpis)

# ============================================
# TOP SCORERS WITH ADVANCED FILTERING
# ============================================
@app.route('/api/top-scorers')
def get_top_scorers():
    position_filter = request.args.get('position', None)
    club_filter = request.args.get('club', None)
    min_goals = request.args.get('min_goals', None)
    
    query = """
        SELECT TOP 20
            p.PlayerName,
            c.ClubName,
            p.Position,
            p.GoalsScored,
            p.Assists,
            p.GoalsScored + p.Assists as TotalContributions,
            p.MarketValue,
            p.Nationality,
            p.Age
        FROM Players p
        JOIN Clubs c ON p.ClubID = c.ClubID
        WHERE 1=1
    """
    
    params = []
    
    if position_filter and position_filter != 'All':
        query += " AND p.Position = ?"
        params.append(position_filter)
    
    if club_filter:
        query += " AND c.ClubName = ?"
        params.append(club_filter)
    
    if min_goals:
        query += " AND p.GoalsScored >= ?"
        params.append(int(min_goals))
    
    query += " ORDER BY p.GoalsScored DESC, p.Assists DESC"
    
    results = execute_query(query, params if params else None)
    return jsonify(results or [])

# ============================================
# PLAYER EFFICIENCY (NEW - Q8: Value ROI)
# ============================================
@app.route('/api/player-efficiency')
def get_player_efficiency():
    position_filter = request.args.get('position', None)
    club_filter = request.args.get('club', None)
    
    print(f"\n=== Player Efficiency Endpoint Called ===")
    print(f"Position filter: {position_filter}")
    print(f"Club filter: {club_filter}")
    
    query = """
        SELECT TOP 15
            p.PlayerName,
            c.ClubName,
            p.GoalsScored,
            p.MarketValue,
            CAST(p.GoalsScored AS FLOAT) / (p.MarketValue / 1000000.0) as Efficiency
        FROM Players p
        JOIN Clubs c ON p.ClubID = c.ClubID
        WHERE p.GoalsScored > 0 AND p.MarketValue > 0
    """
    
    params = []
    
    if position_filter and position_filter != 'All':
        query += " AND p.Position = ?"
        params.append(position_filter)
        print(f"Added position filter: {position_filter}")
    
    if club_filter:
        query += " AND c.ClubName = ?"
        params.append(club_filter)
        print(f"Added club filter: {club_filter}")
    
    query += " ORDER BY Efficiency DESC"
    
    print(f"Executing query with {len(params)} parameters...")
    results = execute_query(query, params if params else None)
    
    if results:
        print(f"? SUCCESS: Found {len(results)} players")
        for r in results[:3]:
            print(f"  - {r.get('PlayerName')}: Efficiency={r.get('Efficiency'):.4f}")
        print(f"Returning JSON with {len(results)} records\n")
        return jsonify(results)
    else:
        print("? ERROR: No results returned from query\n")
        return jsonify([])


# ============================================
# GOALS PER CLUB WITH FILTERING
# ============================================
@app.route('/api/goals-per-club')
def get_goals_per_club():
    position_filter = request.args.get('position', None)
    club_filter = request.args.get('club', None)
    
    query = """
        SELECT TOP 10
            c.ClubName,
            ISNULL(SUM(p.GoalsScored), 0) as TotalGoals,
            ISNULL(SUM(p.Assists), 0) as TotalAssists,
            COUNT(p.PlayerID) as PlayerCount
        FROM Clubs c
        LEFT JOIN Players p ON c.ClubID = p.ClubID
        WHERE 1=1
    """
    
    params = []
    
    if position_filter and position_filter != 'All':
        query += " AND p.Position = ?"
        params.append(position_filter)
    
    if club_filter:
        query += " AND c.ClubName = ?"
        params.append(club_filter)
    
    query += " GROUP BY c.ClubName ORDER BY TotalGoals DESC"
    
    results = execute_query(query, params if params else None)
    return jsonify(results or [])

# ============================================
# INCOME BREAKDOWN (Q5: Revenue Analysis)
# ============================================
@app.route('/api/income-breakdown')
def get_income_breakdown():
    club_filter = request.args.get('club', None)
    
    query = """
        SELECT 
            c.ClubName as club,
            ISNULL(SUM(CASE WHEN ci.IncomeSource = 'Broadcasting' THEN ci.Amount ELSE 0 END), 0) as Broadcasting,
            ISNULL(SUM(CASE WHEN ci.IncomeSource = 'Sponsorship' THEN ci.Amount ELSE 0 END), 0) as Sponsorship,
            ISNULL(SUM(CASE WHEN ci.IncomeSource = 'Ticket Sales' THEN ci.Amount ELSE 0 END), 0) as TicketSales,
            ISNULL(SUM(CASE WHEN ci.IncomeSource = 'Merchandise' THEN ci.Amount ELSE 0 END), 0) as Merchandise,
            ISNULL(SUM(ci.Amount), 0) as TotalIncome
        FROM Clubs c
        LEFT JOIN ClubIncome ci ON c.ClubID = ci.ClubID AND ci.Season = '2023-24'
    """
    
    params = []
    
    if club_filter:
        query += " WHERE c.ClubName = ?"
        params.append(club_filter)
    
    query += " GROUP BY c.ClubName HAVING SUM(ci.Amount) IS NOT NULL ORDER BY TotalIncome DESC"
    
    results = execute_query(query, params if params else None)
    
    # Debug: print results
    if results:
        print(f"Income data fetched: {len(results)} clubs")
        for r in results[:3]:
            print(f"  {r.get('club')}: Broadcasting={r.get('Broadcasting')}, Total={r.get('TotalIncome')}")
    else:
        print("No income data found!")
    
    return jsonify(results or [])

# ============================================
# SQUAD DEPTH ANALYSIS (Q6: Team Composition)
# ============================================
@app.route('/api/squad-depth')
def get_squad_depth():
    club_filter = request.args.get('club', None)
    
    query = """
        SELECT 
            c.ClubName,
            SUM(CASE WHEN p.Position = 'Goalkeeper' THEN 1 ELSE 0 END) as Goalkeepers,
            SUM(CASE WHEN p.Position = 'Defender' THEN 1 ELSE 0 END) as Defenders,
            SUM(CASE WHEN p.Position = 'Midfielder' THEN 1 ELSE 0 END) as Midfielders,
            SUM(CASE WHEN p.Position = 'Forward' THEN 1 ELSE 0 END) as Forwards,
            COUNT(p.PlayerID) as TotalSquadSize,
            AVG(p.Age) as AvgAge,
            SUM(p.MarketValue) as TotalValue
        FROM Clubs c
        LEFT JOIN Players p ON c.ClubID = p.ClubID
    """
    
    params = []
    if club_filter:
        query += " WHERE c.ClubName = ?"
        params.append(club_filter)
    
    query += " GROUP BY c.ClubName ORDER BY TotalValue DESC"
    
    results = execute_query(query, params if params else None)
    return jsonify(results or [])

# ============================================
# STADIUM ANALYSIS (Q7: Stadium ROI)
# ============================================
@app.route('/api/stadium-analysis')
def get_stadium_analysis():
    query = """
        SELECT 
            c.ClubName,
            c.StadiumName,
            c.StadiumCapacity,
            c.City,
            ISNULL(AVG(g.Attendance), 0) as AvgAttendance,
            ISNULL(MAX(g.Attendance), 0) as MaxAttendance,
            ISNULL(SUM(g.TicketRevenue), 0) as TotalTicketRevenue,
            COUNT(g.GameID) as HomeGames,
            CASE 
                WHEN c.StadiumCapacity > 0 AND COUNT(g.GameID) > 0
                THEN AVG(CAST(g.Attendance AS FLOAT) / c.StadiumCapacity * 100)
                ELSE 0 
            END as UtilizationPercent
        FROM Clubs c
        LEFT JOIN Games g ON c.ClubID = g.HomeClubID AND g.Season = '2023-24'
        GROUP BY c.ClubName, c.StadiumName, c.StadiumCapacity, c.City
        HAVING COUNT(g.GameID) > 0
        ORDER BY TotalTicketRevenue DESC
    """
    
    results = execute_query(query)
    return jsonify(results or [])

# ============================================
# MARKET VALUE DISTRIBUTION (Q4: Squad Value)
# ============================================
@app.route('/api/market-distribution')
def get_market_distribution():
    club_filter = request.args.get('club', None)
    
    query = """
        SELECT 
            p.Position,
            COUNT(*) as PlayerCount,
            ISNULL(SUM(p.MarketValue), 0) as TotalValue,
            ISNULL(AVG(p.MarketValue), 0) as AvgValue
        FROM Players p
    """
    
    params = []
    if club_filter:
        query += " JOIN Clubs c ON p.ClubID = c.ClubID WHERE c.ClubName = ? AND p.MarketValue IS NOT NULL"
        params.append(club_filter)
    else:
        query += " WHERE p.MarketValue IS NOT NULL"
    
    query += " GROUP BY p.Position ORDER BY TotalValue DESC"
    
    results = execute_query(query, params if params else None)
    return jsonify(results or [])

# ============================================
# CLUB RANKINGS (Q2: League Standings)
# ============================================
@app.route('/api/club-rankings')
def get_club_rankings():
    query = """
        SELECT TOP 10
            ClubName,
            CurrentRank,
            TotalPoints,
            Championships,
            City
        FROM Clubs
        ORDER BY CurrentRank ASC
    """
    
    results = execute_query(query)
    return jsonify(results or [])

# ============================================
# FILTER OPTIONS
# ============================================
@app.route('/api/filters/clubs')
def get_clubs_filter():
    query = "SELECT DISTINCT ClubName FROM Clubs ORDER BY ClubName"
    results = execute_query(query)
    return jsonify([row['ClubName'] for row in (results or [])])

@app.route('/api/filters/positions')
def get_positions_filter():
    query = "SELECT DISTINCT Position FROM Players ORDER BY Position"
    results = execute_query(query)
    return jsonify([row['Position'] for row in (results or [])])

# ============================================
# NEW BUSINESS INTELLIGENCE ENDPOINTS
# ============================================

# Q9: Home vs Away Performance
@app.route('/api/home-away-performance')
def get_home_away_performance():
    query = """
        SELECT 
            c.ClubName,
            SUM(CASE WHEN g.HomeClubID = c.ClubID THEN g.HomeScore ELSE 0 END) as HomeGoals,
            SUM(CASE WHEN g.AwayClubID = c.ClubID THEN g.AwayScore ELSE 0 END) as AwayGoals,
            COUNT(CASE WHEN g.HomeClubID = c.ClubID THEN 1 END) as HomeGames,
            COUNT(CASE WHEN g.AwayClubID = c.ClubID THEN 1 END) as AwayGames
        FROM Clubs c
        LEFT JOIN Games g ON (c.ClubID = g.HomeClubID OR c.ClubID = g.AwayClubID)
        WHERE g.Season = '2023-24'
        GROUP BY c.ClubName
        ORDER BY (HomeGoals + AwayGoals) DESC
    """
    results = execute_query(query)
    return jsonify(results or [])

# Q10: Salary Efficiency (Goals per Wage Spent)
@app.route('/api/salary-efficiency')
def get_salary_efficiency():
    query = """
        SELECT TOP 10
            c.ClubName,
            SUM(p.GoalsScored) as TotalGoals,
            SUM(p.WeeklySalary * 52) as AnnualWageBill,
            CASE 
                WHEN SUM(p.WeeklySalary * 52) > 0 
                THEN CAST(SUM(p.GoalsScored) AS FLOAT) / (SUM(p.WeeklySalary * 52) / 1000000.0)
                ELSE 0 
            END as GoalsPerMillionSpent
        FROM Clubs c
        JOIN Players p ON c.ClubID = p.ClubID
        GROUP BY c.ClubName
        HAVING SUM(p.GoalsScored) > 0
        ORDER BY GoalsPerMillionSpent DESC
    """
    results = execute_query(query)
    return jsonify(results or [])

# Q11: Age Distribution Analysis
@app.route('/api/age-distribution')
def get_age_distribution():
    club_filter = request.args.get('club', None)
    
    query = """
        SELECT 
            c.ClubName,
            SUM(CASE WHEN p.Age < 23 THEN 1 ELSE 0 END) as Youth,
            SUM(CASE WHEN p.Age BETWEEN 23 AND 28 THEN 1 ELSE 0 END) as Prime,
            SUM(CASE WHEN p.Age > 28 THEN 1 ELSE 0 END) as Experienced,
            AVG(CAST(p.Age AS FLOAT)) as AvgAge
        FROM Clubs c
        LEFT JOIN Players p ON c.ClubID = p.ClubID
    """
    
    params = []
    if club_filter:
        query += " WHERE c.ClubName = ?"
        params.append(club_filter)
    
    query += " GROUP BY c.ClubName ORDER BY AvgAge"
    
    results = execute_query(query, params if params else None)
    return jsonify(results or [])

# Q12: Branch Investment Analysis
@app.route('/api/branch-analysis')
def get_branch_analysis():
    query = """
        SELECT 
            c.ClubName,
            COUNT(b.BranchID) as TotalBranches,
            SUM(b.AnnualBudget) as TotalBranchBudget,
            SUM(CASE WHEN b.BranchType = 'Training Facility' THEN 1 ELSE 0 END) as TrainingFacilities,
            SUM(CASE WHEN b.BranchType = 'Academy' THEN 1 ELSE 0 END) as Academies
        FROM Clubs c
        LEFT JOIN Branches b ON c.ClubID = b.ClubID
        GROUP BY c.ClubName
        ORDER BY TotalBranchBudget DESC
    """
    results = execute_query(query)
    return jsonify(results or [])

# Q13: Financial Health Score
@app.route('/api/financial-health')
def get_financial_health():
    query = """
        SELECT 
            c.ClubName,
            SUM(ci.Amount) as TotalIncome,
            SUM(p.WeeklySalary * 52) as TotalWageBill,
            SUM(b.AnnualBudget) as BranchCosts,
            (SUM(ci.Amount) - SUM(p.WeeklySalary * 52) - ISNULL(SUM(b.AnnualBudget), 0)) as NetProfit,
            CASE 
                WHEN SUM(p.WeeklySalary * 52) > 0 
                THEN (SUM(ci.Amount) / SUM(p.WeeklySalary * 52)) * 100
                ELSE 0 
            END as IncomeToWageRatio
        FROM Clubs c
        LEFT JOIN ClubIncome ci ON c.ClubID = ci.ClubID AND ci.Season = '2023-24'
        LEFT JOIN Players p ON c.ClubID = p.ClubID
        LEFT JOIN Branches b ON c.ClubID = b.ClubID
        GROUP BY c.ClubName
        ORDER BY NetProfit DESC
    """
    results = execute_query(query)
    return jsonify(results or [])

# ============================================
# DEBUG/TEST ENDPOINTS
# ============================================
@app.route('/api/test-efficiency')
def test_efficiency():
    """Test endpoint to debug efficiency data"""
    query = """
        SELECT TOP 15
            p.PlayerName,
            c.ClubName,
            p.GoalsScored,
            p.MarketValue,
            CAST(p.GoalsScored AS FLOAT) / (p.MarketValue / 1000000.0) as Efficiency
        FROM Players p
        JOIN Clubs c ON p.ClubID = c.ClubID
        WHERE p.GoalsScored > 0 AND p.MarketValue > 0
        ORDER BY Efficiency DESC
    """
    
    results = execute_query(query)
    
    if results:
        print(f"? Test Efficiency Query Success: {len(results)} players found")
        for r in results[:3]:
            print(f"  - {r.get('PlayerName')}: {r.get('Efficiency'):.2f} goals/million")
        return jsonify({
            'success': True,
            'count': len(results),
            'data': results,
            'message': 'Efficiency data retrieved successfully'
        })
    else:
        print("? Test Efficiency Query Failed: No data returned")
        return jsonify({
            'success': False,
            'count': 0,
            'data': [],
            'message': 'No efficiency data found - check database'
        }), 500

@app.route('/api/test-connection')
def test_connection():
    """Test database connection"""
    try:
        conn = get_db_connection()
        if conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM Players")
            count = cursor.fetchone()[0]
            cursor.close()
            conn.close()
            return jsonify({
                'success': True,
                'message': f'Database connected successfully. Players count: {count}'
            })
        else:
            return jsonify({
                'success': False,
                'message': 'Failed to connect to database'
            }), 500
    except Exception as e:
        return jsonify({
            'success': False,
            'message': f'Database error: {str(e)}'
        }), 500

@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Endpoint not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

if __name__ == '__main__':
    print("=" * 70)
    print("   PREMIER LEAGUE ANALYTICS DASHBOARD - ENHANCED VERSION")
    print("=" * 70)
    print("\nStarting Flask server...")
    print("Dashboard URL: http://127.0.0.1:5000")
    print("=" * 70)
    print("\n?? BUSINESS QUESTIONS ANSWERED:")
    print("=" * 70)
    print("Q1:  Player Performance - Who are the top scorers?")
    print("Q2:  League Standings - Current club rankings")
    print("Q3:  Attack Analysis - Goals scored by each club")
    print("Q4:  Squad Value - Market value distribution by position")
    print("Q5:  Revenue Streams - Income breakdown by source")
    print("Q6:  Squad Composition - Team depth by position")
    print("Q7:  Stadium ROI - Revenue vs capacity utilization")
    print("Q8:  Value Efficiency - Goals per million spent on players")
    print("Q9:  Home vs Away - Performance comparison")
    print("Q10: Salary Efficiency - Goals per wage spent")
    print("Q11: Age Distribution - Youth vs experience investment")
    print("Q12: Branch Investment - Training facility spending")
    print("Q13: Financial Health - Income vs expenses analysis")
    print("=" * 70)
    print("\n? INTERACTIVE FILTERS:")
    print("  - Club selection")
    print("  - Position filtering")
    print("  - Minimum goals threshold")
    print("=" * 70)
    
    app.run(debug=True, port=5000)